#include <stdio.h>
#include "mcce.h"

int main()
{
    FILE *fp;
    PROT prot;
    int kr, kc;
    
   /* Do step 0, initialization */
   db_open();
   if (init()) {
      db_close();
      printf("Help message: double check file \"run.prm\" in current directory.\n");
   }
   
   if (!(fp=fopen("step2_out.pdb", "r"))) {
      printf("   FATAL: No input \"step2_out.pdb\".\n");
      return USERERR;
   }
   prot = load_pdb(fp);
   if (prot.n_res == 0) {
      printf("   There are errors in pdb file, quiting ...\n");
      return USERERR;
   }
   fclose(fp);
   
   id_conf(prot);
   
   fp = fopen("conf.acc","w");
   sas_native(prot);
   for (kr=0; kr<prot.n_res; kr++) {
      for (kc=1; kc<prot.res[kr].n_conf; kc++) {
         fprintf(fp, "%s %8.3f %8.3f\n",prot.res[kr].conf[kc].uniqID, prot.res[kr].conf[kc].sas, prot.res[kr].conf[kc].sas_fraction);
      }
   }
   
   db_close();
   return 0;
}

